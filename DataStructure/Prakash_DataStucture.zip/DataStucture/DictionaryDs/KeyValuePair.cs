namespace DictionaryDs
{
    public class KeyValuePair<TypeKey,TypeValue>
    {
        public TypeKey Key { get; set; }
        public TypeValue Value { get; set; }

    }
}