global using NUnit.Framework;

public class Maths
{
    public dynamic Addition(dynamic num1,dynamic num2)
    {
        return num1+num2;
    }
}